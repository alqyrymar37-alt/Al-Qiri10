package com.alqiri.legend

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.alqiri.legend.databinding.ActivityMainBinding
import com.alqiri.legend.databinding.DialogParentalFixedBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val appBrain = Brain()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setupListeners()
    }

    private fun setupListeners() {
        binding.btnSecureAction.setOnClickListener {
            showParentalDialog()
        }
    }

    private fun showParentalDialog() {
        val dialogBinding = DialogParentalFixedBinding.inflate(layoutInflater)
        val dialog = AlertDialog.Builder(this)
            .setView(dialogBinding.root)
            .setCancelable(true)
            .create()

        val questionData = appBrain.generateParentalQuestion()
        dialogBinding.tvParentalQuestion.text = questionData.first

        dialogBinding.btnParentalConfirm.setOnClickListener {
            val userAnswer = dialogBinding.etParentalAnswer.text.toString()
            if (appBrain.verifyAnswer(userAnswer)) {
                Toast.makeText(this, "Access Granted", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
                executeSecureLogic()
            } else {
                Toast.makeText(this, "Incorrect. Try again.", Toast.LENGTH_SHORT).show()
            }
        }
        dialog.show()
    }

    private fun executeSecureLogic() {
        val response = appBrain.processInput("status")
        binding.tvStatusDisplay.text = response
    }
}
