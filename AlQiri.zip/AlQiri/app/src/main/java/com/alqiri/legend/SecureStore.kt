package com.alqiri.legend

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/** API key + model name, encrypted at rest with the Android Keystore. */
object SecureStore {
    @Volatile private var cached: SharedPreferences? = null

    private fun prefs(ctx: Context): SharedPreferences = cached ?: synchronized(this) {
        cached ?: run {
            val app = ctx.applicationContext
            val key = MasterKey.Builder(app).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
            EncryptedSharedPreferences.create(
                app, "alqiri_secure", key,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
        }.also { cached = it }
    }

    fun apiKey(ctx: Context): String = prefs(ctx).getString("api_key", "") ?: ""
    fun model(ctx: Context): String = prefs(ctx).getString("model", "claude-sonnet-5") ?: "claude-sonnet-5"

    fun save(ctx: Context, apiKey: String, model: String) {
        prefs(ctx).edit()
            .putString("api_key", apiKey)
            .putString("model", model.ifBlank { "claude-sonnet-5" })
            .apply()
    }
}
